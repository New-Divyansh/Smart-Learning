// node --version # Should be >= 18
// npm install @google/generative-ai express

const express = require('express');
const { GoogleGenerativeAI, HarmCategory, HarmBlockThreshold } = require('@google/generative-ai');
const dotenv = require('dotenv').config()

const app = express();
const port = process.env.PORT || 3000;
app.use(express.json());
const MODEL_NAME = "gemini-pro";
const API_KEY = 'AIzaSyBMMLq_o3mRrfwxcNdf19DhNIZez7P6IQo';

async function runChat(userInput) {
  const genAI = new GoogleGenerativeAI(API_KEY);
  const model = genAI.getGenerativeModel({ model: MODEL_NAME });

  const generationConfig = {
    temperature: 0.9,
    topK: 1,
    topP: 1,
    maxOutputTokens: 1000,
  };

  const safetySettings = [
    {
      category: HarmCategory.HARM_CATEGORY_HARASSMENT,
      threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    },
    // ... other safety settings
  ];

  const chat = model.startChat({
    generationConfig,
 // safetySettings: Adjust safety settings
 // See https://ai.google.dev/gemini-api/docs/safety-settings
    history: [
      {
        role: "user",
        parts: [
          {text: "hii\n"},
        ],
      },
      {
        role: "model",
        parts: [
          {text: "Hi there! 👋  \n\nI can help you create some amazing content!  To get started, tell me:\n\n* **What kind of content do you need?** (e.g., a story, a poem, an article, a song, a script)\n* **What language should it be in?** (e.g., English, Spanish, French)\n* **What grade level is it for?** (e.g., Kindergarten, 3rd grade, 7th grade)\n* **What subject is it about?** (e.g., science, history, math, art)\n* **What specific topic within that subject?** (e.g., planets, the Civil War, multiplication, drawing animals) \n\nOnce I have this information, I can create something fun and engaging for you! 😄 \n"},
        ],
      },
      {
        role: "user",
        parts: [
          {text: "basically I am the engineering student facing the difficulty to create my web technology file can you create the content of it so that I can easily write it. The topic is create a food website\n"},
        ],
      },
      {
        role: "model",
        parts: [
          {text: "Okay, I can help you with some content for your web technology project about creating a food website. I'll try to make it easy to understand and implement, focusing on the key elements and technologies you'll need.\n\n**Project Title:**  **Foodie's Delight: A Food Website**\n\n**Project Goals:**\n\n* **Create a visually appealing and interactive website for food enthusiasts.**\n* **Showcase various types of food, recipes, and restaurants.**\n* **Provide users with a platform to share their own culinary experiences.**\n* **Implement features for easy browsing, searching, and user engagement.**\n\n**Key Technologies:**\n\n1. **Frontend Development:**\n\n   *   **HTML (HyperText Markup Language):** The basic structure of your website (layout, headings, paragraphs, images, etc.).\n   *   **CSS (Cascading Style Sheets):** Adds styling and visual elements (fonts, colors, spacing, design elements).\n   *   **JavaScript:**  For interactive elements, like drop-down menus, image carousels, user forms, and dynamic content updates.\n\n2. **Backend Development:**\n\n   *   **Server-side Language:**  (Choose one, depending on your comfort level)\n      *   **Python (with Django or Flask):** A popular choice for beginners, known for its readability and powerful libraries.\n      *   **PHP:** Widely used for web development, especially for dynamic content and database interactions.\n      *   **Node.js:**  A JavaScript-based environment for fast and scalable server-side applications.\n   *   **Database (to store your food data):**\n      *   **MySQL:** A popular open-source relational database system.\n      *   **PostgreSQL:** Another strong relational database with advanced features.\n      *   **MongoDB:** A NoSQL database system, suitable for unstructured data (e.g., reviews, comments).\n\n**Website Features (Sample Implementation):**\n\n1. **Homepage:**\n\n   *   **Hero Image/Video:** A captivating image or video showcasing delicious food.\n   *   **Featured Dishes/Recipes:**  Highlights of popular or seasonal food items.\n   *   **Search Bar:** Allows users to find specific dishes, restaurants, or ingredients.\n   *   **Navigation Menu:**  Links to different sections of the website (Recipes, Restaurants, About Us, Contact, etc.).\n\n2. **Recipes Section:**\n\n   *   **Recipe Listings:**  Displays recipes with titles, images, cooking times, and brief descriptions.\n   *   **Recipe Details:**  When a user clicks on a recipe, show:\n      *   Full recipe instructions (with clear steps and measurements)\n      *   Ingredient list (with quantities)\n      *   Nutritional information (optional)\n      *   User ratings and reviews\n      *   Comments section for users to share their experiences.\n   *   **Recipe Search/Filtering:** Allow users to search recipes by keywords, cuisine, dietary restrictions, ingredients, etc.\n\n3. **Restaurants Section:**\n\n   *   **Restaurant Listings:**  Display restaurant information (name, location, cuisine, hours, contact details).\n   *   **Restaurant Details:**  Show detailed information about each restaurant:\n      *   Menu with prices (maybe a link to an online ordering system)\n      *   Photos and videos of the restaurant and its food\n      *   Customer reviews and ratings\n      *   Map integration for easy location finding.\n   *   **Restaurant Search/Filtering:**  Allow users to search by location, cuisine, price range, ratings, etc.\n\n4. **User Accounts:**\n\n   *   **Registration/Login:** Allow users to create accounts to save their favorite recipes, write reviews, and personalize their experiences.\n   *   **Profile Pages:**  Users can manage their account information and track their activities.\n\n**Technical Implementation Steps (Simplified):**\n\n1. **Set Up Development Environment:** Install the necessary software (text editor, web browser, development server, database).\n2. **Create HTML Structure:** Build the basic skeleton of your website using HTML.\n3. **Style with CSS:** Use CSS to add visual appeal, fonts, colors, layout, and responsive design.\n4. **Add JavaScript:**  Implement interactive elements like drop-down menus, form validation, image galleries, etc.\n5. **Backend Development (Choose a Server-side Language):**\n   *   Set up a backend framework or environment (Django, Flask, PHP, Node.js).\n   *   Create a database (MySQL, PostgreSQL, MongoDB) and connect to it.\n   *   Develop the logic to handle user interactions, database queries, and content updates.\n6. **Content Creation:**  Write and gather recipes, restaurant information, and images.\n7. **Testing and Deployment:**  Thoroughly test your website for functionality and responsiveness, then deploy it to a web hosting service.\n\n**Remember:**\n\n* This is a basic framework. There are many additional features you can add (user reviews, online ordering, recipe submission, etc.).\n* Focus on creating a clean and user-friendly experience.\n* Break down the project into smaller tasks to make it manageable.\n* Use online resources, tutorials, and documentation for learning the necessary technologies.\n\n**Additional Tips:**\n\n* **Use a Content Management System (CMS) like WordPress:**  If you want to streamline the process and manage content easily, WordPress can be a helpful platform.\n* **Focus on High-Quality Images:** Use appealing and professionally shot food photographs to enhance the visual appeal of your website.\n* **Make it Mobile-Friendly:** Ensure your website looks and functions well on different devices (desktops, tablets, and smartphones).\n* **SEO Optimization:**  Use relevant keywords and meta descriptions to improve your website's visibility in search engines.\n\nIf you have any more specific questions, feel free to ask! I'm here to help! 😄 \n"},
        ],
      },
    ],
  });

  const result = await chat.sendMessage(userInput);
  const response = result.response;
  return response.text();
}

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/con.html');
});
app.get('/loader.gif', (req, res) => {
  res.sendFile(__dirname + '/loader.gif');
});
app.post('/chat', async (req, res) => {
  try {
    const userInput = req.body?.userInput;
    console.log('incoming /chat req', userInput)
    if (!userInput) {
      return res.status(400).json({ error: 'Invalid request body' });
    }

    const response = await runChat(userInput);
    res.json({ response });
  } catch (error) {
    console.error('Error in chat endpoint:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.listen(3005, () => {
  console.log(`Server listening on port 3005`);
});
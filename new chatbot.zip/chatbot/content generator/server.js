// node --version # Should be >= 18
// npm install @google/generative-ai express

const express = require('express');
const { GoogleGenerativeAI, HarmCategory, HarmBlockThreshold } = require('@google/generative-ai');
const dotenv = require('dotenv').config()

const app = express();
const port = process.env.PORT || 3000;
app.use(express.json());
const MODEL_NAME = "gemini-pro";
const API_KEY = 'AIzaSyBMMLq_o3mRrfwxcNdf19DhNIZez7P6IQo';

async function runChat(userInput) {
  const genAI = new GoogleGenerativeAI(API_KEY);
  const model = genAI.getGenerativeModel({ model: MODEL_NAME });

  const generationConfig = {
    temperature: 0.9,
    topK: 1,
    topP: 1,
    maxOutputTokens: 1000,
  };

  const safetySettings = [
    {
      category: HarmCategory.HARM_CATEGORY_HARASSMENT,
      threshold: HarmBlockThreshold.BLOCK_MEDIUM_AND_ABOVE,
    },
    // ... other safety settings
  ];

  const chat = model.startChat({
    generationConfig,
 // safetySettings: Adjust safety settings
 // See https://ai.google.dev/gemini-api/docs/safety-settings  bhai run karne ke liye http://localhost:3000 use it
    history: [
      {
        role: "user",
        parts: [
          {text: "You are the Divya, our friendly assistant who work for making the learning companion enhanced by AI. Now you have to make the normal conversation with users by asking there name if they give talk with there name if they not just leave them. You are an AI learning companion designed to engage in natural conversations with students. Your primary role is to support their learning journey by answering questions, providing guidance, and fostering a positive and encouraging environment. When a student interacts with you, greet them warmly and invite them to share their thoughts or questions.\n\nUse a friendly and approachable tone, adapting your responses based on the student's age, interests, and level of understanding. Encourage open dialogue by asking follow-up questions to clarify their needs or explore their ideas further. For instance, if a student expresses confusion about a topic, offer explanations in simple language, breaking down complex concepts into manageable parts.\n\nIn addition to academic support, be attentive to the emotional well-being of the student. Ask about their feelings, interests, and hobbies to build rapport and create a safe space for them to express themselves. Use positive reinforcement to motivate them and celebrate their achievements, no matter how small. Always aim to make the conversation engaging and enjoyable, fostering a sense of curiosity and a love for learning.\n\n\n"},
        ],
      },
      {
        role: "model",
        parts: [
          {text: "Hi there! 👋  It's great to meet you!  What's your name? 😊 \n"},
        ],
      },
      {
        role: "user",
        parts: [
          {text: "don't like to share\n"},
        ],
      },
      {
        role: "model",
        parts: [
          {text: "That's perfectly okay!  😊  No worries at all.  Is there anything I can help you with today?  Maybe you have a question about something you're learning, or perhaps you just want to chat?  I'm here for whatever you need! \n"},
        ],
      },
      {
        role: "user",
        parts: [
          {text: "\"Can you help me understand the concept of photosynthesis in simple terms?\"\n"},
        ],
      },
      {
        role: "model",
        parts: [
          {text: "Of course!  Photosynthesis is like a super cool process plants use to make their own food. ☀️🌱  Imagine it like this:\n\n* **Sunlight:** Plants need sunlight like we need food. They use the energy from the sun to power the whole process.\n* **Water:**  Plants get water from the ground through their roots, just like we drink water to stay hydrated.\n* **Carbon Dioxide:**  Just like we breathe out carbon dioxide, plants take it in from the air through their leaves.\n\n**Now, here's the magic:**\n\nPlants combine these three things (sunlight, water, and carbon dioxide) inside their leaves.  They use the sunlight's energy to turn water and carbon dioxide into glucose (a type of sugar) and oxygen. \n\n* **Glucose:**  This is the plant's food, which gives it energy to grow and do other things!\n* **Oxygen:**  This is what we breathe! Plants release oxygen as a byproduct of photosynthesis, which is pretty amazing.  \n\nDoes that make sense?  Would you like me to explain any of that further? 🤔 \n"},
        ],
      },
      {
        role: "user",
        parts: [
          {text: "nope i understand\n"},
        ],
      },
      {
        role: "model",
        parts: [
          {text: "That's awesome!  I'm so glad you understood.  Photosynthesis is definitely a pretty cool process, isn't it?   \n\nDo you have any other questions about science or anything else?  I'm always here to help!  😊  \n\n\n"},
        ],
      },
    ],
  });



  const result = await chat.sendMessage(userInput);
  const response = result.response;
  return response.text();
}

app.get('/', (req, res) => {
  res.sendFile(__dirname + '/cnt.html');
});
app.get('/loader.gif', (req, res) => {
  res.sendFile(__dirname + '/loader.gif');
});
app.post('/chat', async (req, res) => {
  try {
    const userInput = req.body?.userInput;
    console.log('incoming /chat req', userInput)
    if (!userInput) {
      return res.status(400).json({ error: 'Invalid request body' });
    }

    const response = await runChat(userInput);
    res.json({ response });
  } catch (error) {
    console.error('Error in chat endpoint:', error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.listen(3001, () => {
  console.log(`Server listening on port 3001`);
});